package ejercicios1_ilb;

/**
 * @author Iván López Benítez
 * Ejercicio2: LeerNombre
 */

public class LeerNombre {
    public static void main(String[] args) {
        //Crea un progerama llamado LeerNombre que reciba un nombre por argumento y lo muestre por pantalla.
        System.out.println(args[0]);
    }
}
